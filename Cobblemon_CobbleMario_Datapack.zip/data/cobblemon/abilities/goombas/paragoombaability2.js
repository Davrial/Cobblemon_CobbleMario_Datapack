{
    onSourceModifyDamage(damage, source, target, move) {
    	const boostedMoves = [
    		'stomp', 'bodyslam', 'flyingpress', 'heavyslam', 'maliciousmoonsault',  'jumpkick', 'highjumpkick', 'bounce', 'supersonicskystrike', 'acrobatics', 'floatyfall', 'fly', 'skyattack',  'headbonk', 'multibonk', 'divekick'
    	];
    	if (fromAboveMoves1.includes(move.id) || move.flags["fromabove"]) {
    		return this.chainModify(1.5);
    	}
    },
    onDamagePriority: 1,
        onDamage(damage, target, source, effect) {
          if (effect?.effectType === "Move" && ["goombaparagoombaflying"].includes(target.species.id)) {
            this.add("-activate", target, "ability: Paragoomba Ability");
            this.effectState.paragoombagrounded = true;
          }
        },
        onUpdate(pokemon) {
          if (["goombaparagoombaflying"].includes(pokemon.species.id) && this.effectState.paragoombagrounded) {
            this.hint('True');
          }
        },
    flags: {},
	name: "Paragoomba Ability 2",
	rating: -1
}
