{
    onSourceModifyDamage(damage, source, target, move) {
        let hitYet = 1;
        const boostedMoves = [
            'stomp', 'bodyslam', 'flyingpress', 'heavyslam', 'maliciousmoonsault',  'jumpkick', 'highjumpkick', 'bounce', 'supersonicskystrike', 'acrobatics', 'floatyfall', 'fly', 'skyattack',  'headbonk', 'multibonk', 'divekick'
        ];
        if (fromAboveMoves1.includes(move.id) || move.flags["fromabove"]) {
            return this.chainModify(1.5);
        }
    },
    onDamagingHit(damage, target, source, move) {
      let hitYet = 1;
      if (fromAboveMoves1.includes(move.id) || move.flags["fromabove"]) {
        if (hitYet = 1){
            source.setType(pokemon.getTypes(true).map((type) => type === "Flying" ? "???" : type));
            this.add("-start", pokemon, "typechange", source.getTypes().join("/"), "[from] ability: Paragoomba Ability");
            hitYet = 0;
        }
      }
    },
    flags: {
        failroleplay: 1, noreceiver: 1, noentrain: 1, notrace: 1, failskillswap: 1, cantsuppress: 1,
        breakable: 1, notransform: 1,
    },
    name: "Paragoomba Ability",
    rating: -1
}