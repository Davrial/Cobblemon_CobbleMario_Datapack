({
 		accuracy: 100,
 		basePower: 40,
 		category: "Physical",
 		name: "Fire Shell",
 		pp: 16,
 		priority: 0,
 		flags: {contact: 1, protect: 1, mirror: 1, metronome: 1},
 		secondary: null,
 		target: "normal",
 		type: "Fire",
 		contestType: "Cool",
})