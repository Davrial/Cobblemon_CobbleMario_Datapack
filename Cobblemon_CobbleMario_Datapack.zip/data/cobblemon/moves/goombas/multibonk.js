({
 		accuracy: 100,
 		basePower: 40,
 		category: "Physical",
 		name: "Multibonk",
 		pp: 16,
 		priority: 0,
 		flags: {fromabove: 1, contact: 1, protect: 1, mirror: 1, metronome: 1},
 		multihit: [2, 5],
 		secondary: null,
 		target: "any",
 		type: "Normal",
 		contestType: "Cool",
})