({
 		accuracy: 100,
 		basePower: 60,
 		category: "Physical",
 		name: "Spikebonk",
 		pp: 64,
 		priority: 0,
 		flags: {fromabove: 1, contact: 1, protect: 1, mirror: 1, metronome: 1, slicing: 1},
 		secondary: null,
 		target: "normal",
 		type: "Steel",
 		contestType: "Tough",
})