({
     num: 120,
     accuracy: 100,
     basePower: 200,
     category: "Physical",
     name: "Self-Destruct",
     pp: 5,
     priority: 0,
     flags: { protect: 1, mirror: 1, metronome: 1, noparentalbond: 1, sdexplosion:1, explosive:1 },
     selfdestruct: "always",
     secondary: null,
     target: "allAdjacent",
     type: "Normal",
     contestType: "Beautiful"
   })